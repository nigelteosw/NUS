# Week 12 Notes
**[https://bit.ly/tembu-intel22wk12t](https://bit.ly/tembu-intel22wk12t)**

### The value of Conceptualizing Intelligence
Less reflective, more academic.

### Equality, A Philosophical Paradox
Intelligence purely as computation and equality.
Reference course readings at the beginning.

Looking at the genetic lottery.

Draw on themes of the module
Synthetic - pulling material from different parts of the course

Which particular understanding from intelligence is relevant to Singapore?
How can a policy grounded in evidence be designed to respond to it?

### Jann, Ning, Jia Kai
Good flow of slides, merely reading off the slides, interpersonal intelligence
Self defeating if the people who this mod is meant for is going to SU is.
Specialize first before working with other people?
Introduced to discipline, not only a content area but a way of acquiring knowledge


### Andre, Hao Wen, Dorothy
Workplace inclusivity and language.
- a consulting firm
- Racial bias within shopee
	- Disrespect non Chinese speakers
- Improve effectiveness of workplace communication
- Syntactic and pragmatic operations
	- Distrust between Chinese speaking and non Chinese speaking
	- Do you foresee conflict because this policy is made for the benefit of non Chinese speaking employees causing a divide between 2 communities? How do you mitigate that?
	- Offshoring the company which would be cheaper


### Kok Hai, Marilyn, Rohini and Xinyun
- ECG (education and career guidance)
- intrapersonal and career certainty (positive correlation)
- Job landscape can change rapidly as seen in covid, is there any plans to ensure that they are updated post tertiary education? 
- Specialize first before being grouped into similar interests


Mechanism (and goal) was clear
Lacking on detail
Engaging research 
Context and infrastructure (link to a space on how they operate)

Singaporean specificity not clear + not operationalized 
Ideas of competition and key ideas (meritocracy)

Generally realistic (even despite the limited data sets)

