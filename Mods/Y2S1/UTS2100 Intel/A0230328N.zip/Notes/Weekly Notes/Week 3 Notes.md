# Week 3 Notes#
**[https://bit.ly/tembu-intel22wk3t](https://bit.ly/tembu-intel22wk3t)**

Main idea in Christensen's readings even though is narrative.
Gardner presenting an alternative to g (most intelligences are highly correlated)

Tracing between a game or a test, and what we think we are testing for.

White middle class populations for IQ testing, skewed towards certain types of upbringing, better environment.

People who are developed not punished. NUS.
Bankers can get away with doing terrible things. 

Why might I argue for IQ testing being a technology? What are the outcomes of this approach?

Author says heres the story
ask a question about testing and the uses of testing in the education system and beyond
education of policies and use of exams in the education
formulate a qn that addresses the use of tests? purpose? testing on within the education system?

Why is the benchmark for the PISA test only for the math and sciences and reading?

attracting foreign investment using PISA rankings. Drove the way for our education system.

How does g deal with adult life? 

1) Decide if someone can cope with a certain kind of education, help people who need help and allocate resources.

2) This is no fun to be part of, highly predictive and deterministic. They have an education existence. Affinity, competing with others.

**What is education for? How does someone who is educated function in a global market?**
How education reforms take place and what reforms take place in the first place.

Big question about Gottfredson. What is it for?
A theory is there to allow us to explore certain scientific concepts and to expand our knowledge. Not stable and always changes. Allows us to pursue greater knowledge and greater truth.