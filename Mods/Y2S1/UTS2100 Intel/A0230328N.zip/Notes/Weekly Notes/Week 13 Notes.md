# Week 13 Notes
**[https://bit.ly/tembu-intel22wk13t](https://bit.ly/tembu-intel22wk13t)**

### What have you learned in this seminar? How do you define intelligence now?
I have learnt that how we define what intelligence is dictates the kind of tests we come up with to try and measure intelligence. For Gardner’s theory, he argues that it is possible to isolate the intelligences into different categories and these can be measured somewhat independently. IQ testing is to me now a form of technology as it is determined by the society that comes up with such IQ tests and what is important to the society. In Singapore's context,  21st century competencies have been prioritized which leads to an emphasis on testing language and STEM subjects. This in turn has led to a form of classism in Singapore as parents' thoughts on what intelligence and success is is narrowed to how well their child does in exams; Their perceived competition has led to actual competition in the kind of support and pressure they push on their child.

As for how I would define intelligence, I would say that it is the ability to improve our intelligence/ability. As a believer in nurture over nature, I feel that all humans have some innate potential. Whether we use that potential depends on many external factors, like whether our parents smoke, the kind of nourishment we get growing up. Provided opportunities, I believe that it will increase our capacity to grow our thinking and this in a sense makes us more intelligent. 


**Ideas**
Can operate in different groups but have the same ideas of what intelligence is. G intelligence and multiple intelligence have similar benchmarks on what intelligence is.

IQ testing defining intelligences or strengthening our idea of what intelligence is instead of the other way around.

