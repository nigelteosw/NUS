# Week 7 Notes
**[https://bit.ly/tembu-intel22wk7t](https://bit.ly/tembu-intel22wk7t)**

## Tembusu Conversations
General intelligence is very hard to model
Machines find it hard to step out of the circle to judge the ecosystem as a whole
- machines are very specialized

## Ex Machina
Machines have motivations?
The possibility that robots can be evil

## Futures
1. In a talk (persuasion)
2. In a movie (makes no attempt at hiding that its fiction)

- Making assumptions on the way the world the will look.
- Relies on extrapolating data
- Problem oriented based of an existing issue
- Future way of life (little or a lot of power and ability to exert agency)
- Deeply connected to science and technology


Is this a (good) policy? If so, makes it a policy? What definition / conception of intelligence does it rest on?

What are the features of a ‘good’ policy?

*What is a policy?*
a course or principle of action adopted or proposed by an organization or individual.

- Clear target audience
- KPI key performance indicators
- Good intentions

Symptoms of a policy (guideline)

1. Policy Goals
2. Policy Means

A policy instrument has a form and rests on goals on a national level.

Its just a initiative to help people from an organisation
Principles of a policy
- Aim and achieve the goals set by the policy 
- *Ideological standpoint*
- *Policy has an impact*


A policy is BY someone, FOR someone.
- Who those actors are are important
- Most likely linked to education
	- Not to go to education
	- Step outside our own world and into another sector


Intelligence can be nurtured. People can grow into the role of a teacher, pick up skills. 
Assumption that intelligence is general
Fluid (raw horsepower)
Crystalised (space to operate the intelligence)

### Assumptions and Feasibility
Reskilling at a older age, can be problematic
Human capital is not just a resource that starts at 20 and ends at 60

Namedropped Freya and Yirui
Fragments of data are missing

Be careful about aggregation

Scale is a very important idea.
What scale does it become problematic.

## This discussion will consider questions concerning policies and how to create them.


