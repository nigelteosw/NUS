# Frames of Mind#
**Gardners (1983)**


## Part 4##

There will never be a master list of three, seven, or three hundred intelligences that can be endorsed by all investigators. There will never be a good enough definition. 

There is a base intelligence (g), indicator of intelligence, reliant of the environment.

**Criteria of an Intelligence**